# DataLife ERP - دليل النشر الكامل

## 🚀 نشر التطبيق على المنصات السحابية

---

## المتطلبات الأساسية

- ✅ حساب GitHub (لحفظ الكود)
- ✅ حساب Vercel (للـ Frontend)
- ✅ حساب Railway (للـ Backend)
- ✅ حساب MongoDB Atlas (لقاعدة البيانات)

جميع الحسابات مجانية للبدء!

---

## الخطوة 1: حفظ الكود على GitHub

### الطريقة الأولى: من خلال Emergent
1. اضغط زر **"Save to GitHub"** في واجهة المحادثة
2. اختر مستودع موجود أو أنشئ جديد
3. انتظر حتى ينتهي الرفع

### الطريقة الثانية: يدوياً
1. حمّل الملفات من VS Code viewer
2. أنشئ مستودع جديد على GitHub
3. ارفع الملفات يدوياً

---

## الخطوة 2: إعداد قاعدة البيانات (MongoDB Atlas)

### 2.1 إنشاء Cluster
```bash
1. اذهب إلى: https://mongodb.com/cloud/atlas
2. سجل دخول أو أنشئ حساب
3. اضغط "Build a Database"
4. اختر "Free" (M0 Sandbox)
5. اختر Provider و Region (أقرب موقع لك)
6. اضغط "Create"
```

### 2.2 إعداد الوصول
```bash
1. في Security -> Database Access:
   - أنشئ مستخدم جديد
   - احفظ Username و Password

2. في Security -> Network Access:
   - اضغط "Add IP Address"
   - اختر "Allow Access from Anywhere" (0.0.0.0/0)
   - اضغط "Confirm"
```

### 2.3 الحصول على Connection String
```bash
1. اذهب إلى Database -> Connect
2. اختر "Connect your application"
3. انسخ Connection String
4. استبدل <password> بكلمة المرور الخاصة بك
5. استبدل <database> بـ "datalife_erp"

مثال:
mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/datalife_erp
```

---

## الخطوة 3: نشر Backend (Railway)

### 3.1 إنشاء مشروع جديد
```bash
1. اذهب إلى: https://railway.app
2. سجل دخول بحساب GitHub
3. اضغط "New Project"
4. اختر "Deploy from GitHub repo"
5. اختر المستودع الخاص بك
6. اضغط "Deploy Now"
```

### 3.2 إعداد المتغيرات البيئية
```bash
1. اذهب إلى Settings -> Variables
2. أضف المتغيرات التالية:

MONGO_URL=mongodb+srv://username:password@cluster.mongodb.net/datalife_erp
JWT_SECRET_KEY=feWfN9igT1P1NpiWI3_M1WK_bpK1JZzbY9nbfu81gLI
CORS_ORIGINS=https://your-frontend.vercel.app
DB_NAME=datalife_erp

3. احفظ التغييرات
```

### 3.3 تكوين المشروع
```bash
1. في Settings:
   - Root Directory: backend
   - Start Command: uvicorn server:app --host 0.0.0.0 --port $PORT

2. احفظ التغييرات
3. انتظر حتى ينتهي الـ deployment
4. احصل على الرابط من Settings -> Domains
```

---

## الخطوة 4: نشر Frontend (Vercel)

### 4.1 إنشاء مشروع جديد
```bash
1. اذهب إلى: https://vercel.com
2. سجل دخول بحساب GitHub
3. اضغط "Add New..." -> "Project"
4. اختر المستودع الخاص بك
5. Configure Project:
   - Framework Preset: Create React App
   - Root Directory: frontend
   - Build Command: yarn build
   - Output Directory: build
```

### 4.2 إعداد المتغيرات البيئية
```bash
1. في Settings -> Environment Variables
2. أضف المتغير التالي:

Name: REACT_APP_BACKEND_URL
Value: https://your-backend.railway.app

3. اضغط "Save"
```

### 4.3 إعادة النشر
```bash
1. اذهب إلى Deployments
2. اضغط على آخر deployment
3. اضغط "..." -> "Redeploy"
4. انتظر حتى ينتهي
5. احصل على الرابط من أعلى الصفحة
```

---

## الخطوة 5: تحديث CORS في Backend

### 5.1 تحديث المتغيرات
```bash
1. ارجع لـ Railway
2. اذهب إلى Variables
3. حدّث CORS_ORIGINS:

CORS_ORIGINS=https://your-frontend.vercel.app,https://www.your-domain.com

4. احفظ وانتظر إعادة التشغيل التلقائية
```

---

## الخطوة 6: اختبار التطبيق

### 6.1 الاختبار الأساسي
```bash
✅ افتح رابط Vercel في المتصفح
✅ جرب تسجيل الدخول
✅ اختبر إضافة بيانات
✅ تأكد من ظهور البيانات بعد Refresh
```

### 6.2 الاختبار على الموبايل
```bash
✅ افتح الرابط على iPhone/Android
✅ تأكد من الـ responsive design
✅ جرب جميع الوظائف
✅ احفظه على Home Screen
```

---

## الخطوة 7: Domain مخصص (اختياري)

### 7.1 في Vercel
```bash
1. Settings -> Domains
2. أضف Domain الخاص بك
3. اتبع تعليمات DNS
```

### 7.2 في Railway
```bash
1. Settings -> Domains
2. أضف Custom Domain
3. اتبع تعليمات DNS
```

---

## 🔧 استكشاف المشاكل

### المشكلة: Backend لا يستجيب
**الحل:**
1. تحقق من Logs في Railway
2. تأكد من MONGO_URL صحيح
3. تأكد من Port configuration

### المشكلة: Frontend لا يتصل بـ Backend
**الحل:**
1. تحقق من REACT_APP_BACKEND_URL
2. تحقق من CORS_ORIGINS في Backend
3. افحص Network tab في Browser Console

### المشكلة: Database connection error
**الحل:**
1. تحقق من MongoDB Atlas Network Access
2. تأكد من صحة Username/Password
3. تأكد من Connection String

---

## 📊 المراقبة والصيانة

### مراقبة الأداء
```bash
- Railway Dashboard: معلومات الاستخدام والأداء
- Vercel Analytics: معلومات الزوار
- MongoDB Atlas: حجم قاعدة البيانات
```

### النسخ الاحتياطي
```bash
1. MongoDB Atlas -> Backup (تلقائي في الخطط المدفوعة)
2. أو استخدام mongodump يدوياً:
   mongodump --uri="mongodb+srv://..."
```

### التحديثات
```bash
1. عدّل الكود في GitHub
2. Push التغييرات
3. Vercel و Railway سيعيدان النشر تلقائياً
```

---

## 💡 نصائح الإنتاج

### الأمان
- ✅ استخدم HTTPS فقط
- ✅ حدّث Dependencies بانتظام
- ✅ راقب Logs للأخطاء
- ✅ فعّل 2FA على جميع الحسابات

### الأداء
- ✅ استخدم CDN لـ Static files
- ✅ فعّل Caching
- ✅ راقب Database queries
- ✅ استخدم MongoDB indexes

### التكلفة
- ✅ ابدأ بالخطط المجانية
- ✅ ارفع عند الحاجة فقط
- ✅ راقب الاستخدام شهرياً
- ✅ احذف المشاريع غير المستخدمة

---

## 📞 الدعم

### مشاكل في النشر؟
- **Discord**: https://discord.gg/VzKfwCXC4A
- **Email**: support@emergent.sh

### وثائق المنصات:
- **Railway**: https://docs.railway.app
- **Vercel**: https://vercel.com/docs
- **MongoDB Atlas**: https://docs.atlas.mongodb.com

---

## ✅ Checklist النشر النهائي

```bash
[ ] الكود محفوظ على GitHub
[ ] MongoDB Atlas cluster جاهز
[ ] Backend منشور على Railway
[ ] Frontend منشور على Vercel
[ ] Environment variables محدّثة
[ ] CORS origins صحيحة
[ ] Login يعمل
[ ] CRUD operations تعمل
[ ] Mobile responsive يعمل
[ ] Multi-tenant isolation يعمل
[ ] Domain مخصص (اختياري)
```

---

**نسخة الدليل**: 1.0  
**آخر تحديث**: يناير 2025  
**الحالة**: جاهز للإنتاج ✅

---

## 🎉 تهانينا!

تطبيقك الآن منشور ويعمل على:
- 🌐 الويب (Desktop)
- 📱 الموبايل (iOS/Android)
- 📊 التابلت
- 💼 جاهز للاستخدام الإنتاجي!
