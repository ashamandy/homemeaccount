export const translations = {
  en: {
    // Navigation
    nav: {
      features: "Features",
      modules: "Modules", 
      pricing: "Pricing",
      getStarted: "Get Started"
    },
    
    // Hero Section
    hero: {
      badge: "All-in-One Business Management Solution",
      title: "Your Complete Solution for",
      titleHighlight: "Business Management",
      description: "Say goodbye to fragmented programs and scattered data. DataLife Account combines HR, production, accounting, and cost management into one powerful platform for maximum efficiency and control.",
      startTrial: "Start Free Trial",
      watchDemo: "Watch Demo",
      noSetupFees: "No Setup Fees",
      support247: "24/7 Support",
      cloudBased: "Cloud-Based"
    },

    // Features Section
    features: {
      title: "Everything Your Business Needs",
      description: "From HR management to financial reporting, DataLife Account provides comprehensive tools to streamline every aspect of your business operations.",
      items: {
        hr: {
          title: "HR Management",
          description: "Complete employee data management, attendance tracking, automated salary calculations, and health insurance records with fingerprint integration."
        },
        financial: {
          title: "Financial Management", 
          description: "Track daily transactions, manage accounts payable/receivable, monitor fixed assets, and record all business expenses seamlessly."
        },
        production: {
          title: "Production & Inventory",
          description: "Monitor inventory movement, manage production orders, track material needs, and optimize supply chain operations."
        },
        cost: {
          title: "Cost Management",
          description: "Calculate production and service costs accurately with detailed profit and loss reports for informed decision-making."
        },
        banking: {
          title: "Accounts & Banking",
          description: "Comprehensive management of company accounts, check processing, and debt tracking for suppliers and customers."
        },
        analytics: {
          title: "Analytics & Reports",
          description: "Generate accurate financial statements, visual reports with graphs, and automated VAT breakdowns for strategic insights."
        }
      }
    },

    // Benefits Section
    benefits: {
      title: "Why Choose DataLife Account?",
      description: "Built for businesses that demand excellence, reliability, and comprehensive functionality.",
      items: {
        easeOfUse: {
          title: "Ease of Use",
          description: "Simple and flexible interface with clear menus for daily operations"
        },
        integration: {
          title: "Seamless Integration", 
          description: "Easily integrate with existing CRM and inventory management systems"
        },
        security: {
          title: "Robust Security",
          description: "High-level security layers to protect your sensitive financial data"
        },
        support: {
          title: "24/7 Support",
          description: "Continuous updates and around-the-clock technical support"
        },
        cloud: {
          title: "Cloud Computing",
          description: "Access your data from anywhere, anytime with cloud flexibility"
        },
        notifications: {
          title: "Automated Notifications",
          description: "Get alerts for important financial matters and pending payments"
        }
      }
    },

    // Modules Section
    modules: {
      title: "Key Program Features",
      description: "Explore the comprehensive modules that make DataLife Account your complete business solution.",
      items: {
        customization: {
          title: "Full Customization",
          features: [
            "Personalized setup for each client",
            "Company logo and user photo integration", 
            "Remote control and updates"
          ]
        },
        hr: {
          title: "HR Management",
          features: [
            "Complete employee database",
            "Attendance and leave tracking",
            "Automated salary calculations",
            "Fingerprint device integration",
            "Health insurance management"
          ]
        },
        financial: {
          title: "Financial Operations",
          features: [
            "Production & inventory monitoring",
            "Cost management and analysis",
            "Banking and payment processing",
            "Online obligation settlements",
            "Automatic payment reminders"
          ]
        },
        analytics: {
          title: "Analytics & Control",
          features: [
            "Permission-based access control",
            "Visual reports with graphs",
            "Automated financial statements",
            "Custom report generation", 
            "VAT breakdown automation"
          ]
        }
      }
    },

    // Testimonials
    testimonials: {
      title: "Trusted by Business Leaders",
      description: "See how DataLife Account has transformed businesses across various industries.",
      items: [
        {
          name: "Ahmed Hassan",
          role: "CEO, Manufacturing Co.",
          content: "DataLife Account transformed our business operations. The integrated approach saved us countless hours and improved our financial accuracy."
        },
        {
          name: "Fatima Al-Zahra", 
          role: "HR Director",
          content: "The HR module is exceptional. Employee management, attendance tracking, and salary calculations are now completely automated."
        },
        {
          name: "Omar Rashid",
          role: "Finance Manager", 
          content: "Finally, a system that handles everything from inventory to financial reporting. The visual reports make decision-making so much easier."
        }
      ]
    },

    // CTA Section
    cta: {
      title: "Ready to Transform Your Business?",
      description: "Join thousands of businesses that have streamlined their operations with DataLife Account. Start your free trial today.",
      startTrial: "Start Free Trial",
      contactSales: "Contact Sales"
    },

    // Footer
    footer: {
      description: "Your partner in business success through comprehensive management solutions.",
      product: "Product",
      support: "Support", 
      company: "Company",
      features: "Features",
      pricing: "Pricing",
      demo: "Demo",
      documentation: "Documentation",
      helpCenter: "Help Center",
      contact: "Contact",
      about: "About",
      careers: "Careers",
      privacy: "Privacy",
      copyright: "© 2025 DataLife Account. All rights reserved."
    },

    // Contact Information
    contact: {
      title: "Contact Information",
      address: "59 Lebanon Street, Mohandessin, Giza, Egypt",
      phone: "(+2) 01012625529",
      email: "info@datalifeai.com",
      businessHours: "Sunday - Thursday: 9:00 AM - 6:00 PM",
      getInTouch: "Get in Touch",
      contactSales: "Contact Sales Team",
      scheduleDemo: "Schedule a Demo",
      visitOffice: "Visit Our Office",
      callUs: "Call Us",
      emailUs: "Email Us"
    },

    // Pricing Section
    pricing: {
      badge: "Flexible Pricing Plans",
      title: "Choose the Perfect Plan for Your Business",
      description: "From startups to enterprises, we have pricing options that scale with your business needs and budget.",
      popular: "Most Popular",
      recommended: "Recommended",
      employees: "employees",
      
      tabs: {
        subscription: "Subscription Plans",
        modules: "Module Packages",
        onetime: "One-time Setup"
      },

      billing: {
        monthly: "Monthly",
        annual: "Annual",
        month: "month",
        year: "year",
        save: "Save 33%",
        savePercent: "Save %d%"
      },

      plans: {
        starter: {
          name: "Starter",
          description: "Perfect for small businesses getting started with digital management",
          features: {
            employees: "Up to 10 employees",
            basicHR: "Basic HR management",
            financial: "Financial tracking & reporting",
            reports: "Monthly financial reports",
            emailSupport: "Email support",
            storage: "5GB cloud storage"
          },
          notIncluded: {
            payroll: "Automated payroll processing",
            advanced: "Advanced analytics & forecasting",
            api: "API integrations"
          },
          button: "Start Free Trial"
        },
        professional: {
          name: "Professional",
          description: "Ideal for growing businesses with comprehensive management needs",
          features: {
            employees: "Up to 100 employees",
            fullHR: "Complete HR & payroll management",
            advanced: "Advanced financial management",
            inventory: "Production & inventory tracking",
            cost: "Cost management & analysis",
            priority: "Priority email & chat support",
            storage: "50GB cloud storage",
            reports: "Custom reports & analytics",
            integrations: "Basic API integrations"
          },
          notIncluded: {
            multiLocation: "Multi-location management",
            dedicated: "Dedicated account manager"
          },
          button: "Get Professional"
        },
        enterprise: {
          name: "Enterprise",
          description: "Comprehensive solution for large organizations with complex requirements",
          unlimited: "Unlimited",
          features: {
            unlimited: "Unlimited employees",
            everything: "All Professional features included",
            multiLocation: "Multi-location & branch management",
            customization: "Custom workflows & integrations",
            dedicated: "Dedicated account manager",
            phone: "24/7 phone & on-site support",
            storage: "Unlimited cloud storage",
            training: "Comprehensive staff training",
            sla: "99.9% uptime SLA guarantee"
          },
          button: "Contact Sales"
        }
      },

      modules: {
        title: "Individual Module Packages",
        description: "Need specific functionality? Choose individual modules that fit your exact business requirements.",
        button: "Get This Module",
        
        hr: {
          name: "HR Management",
          description: "Complete human resources management solution",
          features: {
            employee: "Employee database & profiles",
            attendance: "Attendance & leave tracking",
            payroll: "Automated payroll processing",
            leave: "Leave management system",
            insurance: "Health insurance tracking"
          }
        },
        finance: {
          name: "Financial Management",
          description: "Comprehensive accounting and financial tracking",
          features: {
            accounting: "Complete accounting system",
            invoicing: "Invoicing & billing",
            expenses: "Expense tracking & management",
            banking: "Bank reconciliation",
            reports: "Financial reports & analytics"
          }
        },
        inventory: {
          name: "Inventory & Production",
          description: "Stock management and production planning",
          features: {
            tracking: "Real-time inventory tracking",
            orders: "Production order management",
            suppliers: "Supplier & vendor management",
            analytics: "Inventory analytics & forecasting",
            alerts: "Low stock alerts & notifications"
          }
        }
      },

      oneTime: {
        title: "One-time Setup Packages",
        description: "Get started quickly with our comprehensive setup and training packages.",
        onetime: "one-time payment",
        button: "Purchase Setup",
        
        basic: {
          name: "Basic Setup",
          description: "Essential setup to get your system running",
          features: {
            installation: "System installation & configuration",
            training: "2 hours of staff training",
            data: "Basic data migration (up to 1000 records)",
            support: "30 days email support"
          }
        },
        premium: {
          name: "Premium Setup",
          description: "Complete setup with comprehensive training and support",
          features: {
            everything: "Everything in Basic Setup",
            custom: "Custom workflow configuration",
            integration: "Third-party system integration",
            training: "8 hours of comprehensive training",
            support: "90 days priority support"
          }
        }
      },

      contact: {
        title: "Need a Custom Solution?",
        description: "Contact our sales team for enterprise pricing, custom integrations, or special requirements.",
        demo: "Schedule Demo",
        sales: "Contact Sales"
      }
    },

    // Payment Section
    payment: {
      checkout: "Secure Checkout",
      paymentComplete: "Payment Complete",
      secureCheckout: "Your payment information is secure and encrypted",
      selectMethod: "Select Payment Method",
      paymentDetails: "Payment Details",
      billingInfo: "Billing Information",
      
      methods: {
        card: "Credit/Debit Card",
        cardDesc: "Pay securely with your credit or debit card",
        fawryDesc: "Pay through Fawry locations or mobile app",
        bank: "Bank Transfer",
        bankDesc: "Direct bank transfer (1-2 business days)",
        wallet: "Mobile Wallet",
        walletDesc: "Vodafone Cash, Orange Money, Etisalat Cash"
      },

      instant: "Instant",
      bankTime: "1-2 business days",

      cardNumber: "Card Number",
      expiryDate: "Expiry Date",
      cvv: "CVV",
      cardName: "Cardholder Name",
      cardNamePlaceholder: "Name as it appears on card",
      email: "Email Address",
      phone: "Phone Number",
      companyName: "Company Name",
      companyNamePlaceholder: "Your company name",
      vatNumber: "VAT Number",
      optional: "Optional",
      walletPhone: "Wallet Phone Number",

      fawryInstructions: "Fawry Payment Instructions",
      fawrySteps: "1. Complete this form 2. Visit any Fawry location 3. Use the payment code provided 4. Your account will be activated immediately",
      
      bankInstructions: "Bank Transfer Instructions",
      bankDetails: "Account: DataLife Account Ltd. | Bank: CIB | Account Number: 123456789 | Reference: Your order number",

      back: "Back",
      continue: "Continue",
      cancel: "Cancel",
      payNow: "Pay Now",
      
      processing: "Processing Payment",
      processingDesc: "Please wait while we process your payment. Do not close this window.",
      
      success: "Payment Successful!",
      successDesc: "Your subscription has been activated and you'll receive confirmation details shortly.",
      
      transactionId: "Transaction ID",
      amount: "Amount",
      plan: "Plan",
      save: "You save",
      
      emailSent: "Confirmation email sent",
      smsSent: "SMS notification sent",
      accountActivated: "Account activated",
      getStarted: "Get Started",
      
      securePayment: "256-bit SSL encrypted secure payment"
    },

    // Free Trial Section
    trial: {
      title: "Start Your 14-Day Free Trial",
      description: "Experience the full power of DataLife Account with no commitment. Get instant access to all Professional features.",
      
      benefits: {
        title: "What's Included in Your Free Trial"
      },
      
      features: {
        duration: "14 Days Full Access",
        durationDesc: "Complete trial period with no restrictions",
        employees: "Up to 25 Employees",
        employeesDesc: "Perfect for testing with your team",
        fullAccess: "All Professional Features",
        fullAccessDesc: "HR, Finance, Inventory, Reports & more",
        support: "Email Support",
        supportDesc: "Get help when you need it"
      },

      form: {
        title: "Create Your Free Trial Account",
        firstName: "First Name",
        firstNamePlaceholder: "Enter your first name",
        lastName: "Last Name", 
        lastNamePlaceholder: "Enter your last name",
        email: "Email Address",
        phone: "Phone Number",
        companyName: "Company Name",
        companyNamePlaceholder: "Enter your company name",
        businessInfo: "Business Information (Optional)",
        industry: "Industry",
        selectIndustry: "Select your industry",
        companySize: "Company Size",
        selectSize: "Select company size",
        intendedUse: "Primary Use Case",
        selectUse: "How will you use DataLife?",
        cancel: "Cancel",
        startTrial: "Start My Free Trial"
      },

      processing: {
        title: "Setting Up Your Trial Account",
        description: "Please wait while we prepare your personalized DataLife Account experience..."
      },

      success: {
        header: "Welcome to DataLife Account!",
        title: "Your Free Trial is Ready!",
        description: "We've created your account and populated it with sample data so you can start exploring immediately.",
        trialLength: "Trial Duration",
        days: "days",
        maxEmployees: "Employee Limit",
        employees: "employees",
        features: "Feature Access",
        fullAccess: "All Professional Features",
        emailSent: "Welcome email sent with login details",
        accountCreated: "Trial account created and activated",
        sampleData: "Sample data added for immediate testing",
        accessTrial: "Access My Trial Account"
      },

      security: "No credit card required. Cancel anytime."
    },

    // Demo Section
    demo: {
      title: "DataLife Account - Live Demo",
      subtitle: "Experience the full power of our business management platform",
      demoMode: "Demo Mode",
      guidedTour: "Start Guided Tour",
      
      modules: {
        dashboard: "Dashboard",
        hr: "HR Management", 
        financial: "Financial",
        inventory: "Inventory",
        reports: "Reports",
        analytics: "Analytics"
      },

      kpi: {
        totalEmployees: "Total Employees",
        monthlyRevenue: "Monthly Revenue",
        activeProjects: "Active Projects", 
        efficiency: "Efficiency Rate"
      },

      currency: "EGP",

      quickActions: {
        title: "Quick Actions",
        addEmployee: "Add Employee",
        newTransaction: "New Transaction", 
        generateReport: "Generate Report",
        checkInventory: "Check Inventory"
      },

      recentActivity: {
        title: "Recent Activity"
      },

      upcomingTasks: {
        title: "Upcoming Tasks"
      },

      hr: {
        totalEmployees: "Total Employees",
        presentToday: "Present Today",
        onLeave: "On Leave",
        employeeList: "Employee List",
        addEmployee: "Add Employee",
        employee: "Employee",
        position: "Position",
        department: "Department", 
        status: "Status",
        actions: "Actions"
      },

      financial: {
        recentTransactions: "Recent Transactions",
        newTransaction: "New Transaction",
        date: "Date",
        description: "Description",
        category: "Category",
        amount: "Amount",
        status: "Status"
      },

      inventory: {
        items: "Inventory Items",
        filter: "Filter",
        addItem: "Add Item",
        product: "Product",
        sku: "SKU",
        quantity: "Quantity",
        value: "Value",
        status: "Status"
      },

      reports: {
        financialSummary: "Financial Summary",
        monthlyRevenue: "Monthly Revenue",
        expenses: "Expenses by Category"
      },

      tour: {
        welcome: "Welcome to DataLife Demo!",
        description: "Let us guide you through the key features of DataLife Account.",
        start: "Start Tour"
      },

      employeeForm: {
        tabs: {
          basic: "Basic Information",
          job: "Job Details",
          financial: "Financial Information", 
          documents: "Documents & Files",
          transfers: "Transfer History"
        },
        
        basic: {
          personalInfo: "Personal Information",
          fullName: "Full Name",
          email: "Email Address",
          phone: "Phone Number",
          nationalId: "National ID",
          birthDate: "Birth Date",
          gender: "Gender",
          male: "Male",
          female: "Female",
          maritalStatus: "Marital Status",
          single: "Single",
          married: "Married",
          divorced: "Divorced",
          address: "Address"
        },
        
        job: {
          jobDetails: "Job Details",
          position: "Position",
          department: "Department",
          directManager: "Direct Manager",
          startDate: "Start Date",
          employmentType: "Employment Type",
          fullTime: "Full Time",
          partTime: "Part Time",
          contract: "Contract",
          internship: "Internship",
          workLocation: "Work Location"
        },
        
        financial: {
          salaryInfo: "Financial Information",
          baseSalary: "Base Salary",
          allowances: "Allowances",
          allowanceType: "Allowance Type",
          allowanceAmount: "Allowance Amount",
          transportation: "Transportation",
          housing: "Housing",
          food: "Food",
          communication: "Communication",
          other: "Other",
          deductions: "Deductions",
          deductionType: "Deduction Type",
          deductionAmount: "Deduction Amount",
          insurance: "Insurance",
          tax: "Tax",
          loan: "Loan",
          payrollMethod: "Payroll Method",
          cash: "Cash",
          bank: "Bank Transfer",
          bankAccount: "Bank Account Number"
        },
        
        documents: {
          documentsFiles: "Documents & Files",
          profileImage: "Profile Image",
          uploadImage: "Upload Image",
          cv: "CV/Resume",
          uploadCV: "Upload CV",
          contracts: "Employment Contracts",
          uploadContract: "Upload Contract",
          certificates: "Certificates & Qualifications",
          uploadCertificate: "Upload Certificate",
          supportedFormats: "Supported formats: PDF, DOC, JPG, PNG",
          maxSize: "Max size: 5 MB"
        },
        
        transfers: {
          transferHistory: "Transfer History",
          addTransfer: "Add Transfer",
          fromDepartment: "From Department",
          toDepartment: "To Department",
          transferDate: "Transfer Date",
          reason: "Reason",
          promotion: "Promotion",
          departmentChange: "Department Change",
          locationChange: "Location Change",
          restructuring: "Restructuring",
          notes: "Notes"
        },
        
        actions: {
          save: "Save Employee",
          cancel: "Cancel",
          next: "Next",
          previous: "Previous",
          addAllowance: "Add Allowance",
          addDeduction: "Add Deduction",
          removeAllowance: "Remove Allowance",
          removeDeduction: "Remove Deduction",
          addDepartment: "Add New Department",
          addCustomType: "Add Custom Type"
        },

        customTypes: {
          allowanceTitle: "Add Custom Allowance Type",
          deductionTitle: "Add Custom Deduction Type",
          nameAr: "Arabic Name", 
          nameEn: "English Name",
          save: "Save Type",
          cancel: "Cancel",
          namePlaceholder: "Enter type name",
          custom: "Custom"
        },

        newTransaction: {
          title: "Add New Transaction",
          description: "Description",
          category: "Category",
          amount: "Amount",
          type: "Type",
          date: "Date",
          income: "Income",
          expense: "Expense",
          save: "Save Transaction",
          cancel: "Cancel",
          categories: {
            salary: "Salary",
            rent: "Rent",
            utilities: "Utilities",
            supplies: "Supplies",
            marketing: "Marketing",
            maintenance: "Maintenance",
            sales: "Sales",
            other: "Other"
          }
        },

        addDepartment: {
          title: "Add New Department",
          name: "Department Name",
          nameAr: "Arabic Name",
          nameEn: "English Name",
          description: "Department Description",
          manager: "Department Manager",
          save: "Save Department",
          cancel: "Cancel",
          namePlaceholder: "Enter department name",
          descriptionPlaceholder: "Brief description of the department and its goals"
        }
      }
    }
  },

  ar: {
    // Navigation
    nav: {
      features: "المميزات",
      modules: "الوحدات",
      pricing: "التسعير", 
      getStarted: "ابدأ الآن"
    },

    // Hero Section
    hero: {
      badge: "حل شامل لإدارة الأعمال",
      title: "حلك الكامل لـ",
      titleHighlight: "إدارة الأعمال",
      description: "قل وداعاً للبرامج المتناثرة والبيانات المبعثرة. داتا لايف أكاونت يجمع الموارد البشرية والإنتاج والمحاسبة وإدارة التكاليف في منصة واحدة قوية لتحقيق أقصى كفاءة وتحكم.",
      startTrial: "ابدأ النسخة التجريبية",
      watchDemo: "شاهد العرض التوضيحي",
      noSetupFees: "بدون رسوم إعداد",
      support247: "دعم على مدار الساعة",
      cloudBased: "قائم على السحابة"
    },

    // Features Section  
    features: {
      title: "كل ما يحتاجه عملك",
      description: "من إدارة الموارد البشرية إلى التقارير المالية، يوفر داتا لايف أكاونت أدوات شاملة لتبسيط كل جانب من جوانب عمليات عملك.",
      items: {
        hr: {
          title: "إدارة الموارد البشرية",
          description: "إدارة بيانات الموظفين الكاملة، تتبع الحضور، حسابات الراتب الآلية، وسجلات التأمين الصحي مع التكامل مع بصمة الإصبع."
        },
        financial: {
          title: "الإدارة المالية",
          description: "تتبع المعاملات اليومية، إدارة الحسابات المدينة والدائنة، مراقبة الأصول الثابتة، وتسجيل جميع نفقات العمل بسلاسة."
        },
        production: {
          title: "الإنتاج والمخزون",
          description: "مراقبة حركة المخزون، إدارة أوامر الإنتاج، تتبع احتياجات المواد، وتحسين عمليات سلسلة التوريد."
        },
        cost: {
          title: "إدارة التكاليف",
          description: "حساب تكاليف الإنتاج والخدمات بدقة مع تقارير مفصلة للأرباح والخسائر لاتخاذ قرارات مدروسة."
        },
        banking: {
          title: "الحسابات والمصرفية",
          description: "إدارة شاملة لحسابات الشركة، معالجة الشيكات، وتتبع الديون للموردين والعملاء."
        },
        analytics: {
          title: "التحليلات والتقارير",
          description: "إنشاء بيانات مالية دقيقة، تقارير مرئية بالرسوم البيانية، وتحليل ضريبة القيمة المضافة الآلي للحصول على رؤى استراتيجية."
        }
      }
    },

    // Benefits Section
    benefits: {
      title: "لماذا تختار داتا لايف أكاونت؟",
      description: "مصمم للشركات التي تطلب التميز والموثوقية والوظائف الشاملة.",
      items: {
        easeOfUse: {
          title: "سهولة الاستخدام",
          description: "واجهة بسيطة ومرنة مع قوائم واضحة للعمليات اليومية"
        },
        integration: {
          title: "التكامل السلس",
          description: "تكامل سهل مع أنظمة إدارة علاقات العملاء والمخزون الموجودة"
        },
        security: {
          title: "أمان قوي",
          description: "طبقات أمان عالية المستوى لحماية بياناتك المالية الحساسة"
        },
        support: {
          title: "دعم 24/7",
          description: "تحديثات مستمرة ودعم فني على مدار الساعة"
        },
        cloud: {
          title: "الحوسبة السحابية",
          description: "الوصول إلى بياناتك من أي مكان وفي أي وقت مع مرونة السحابة"
        },
        notifications: {
          title: "الإشعارات الآلية",
          description: "احصل على تنبيهات للأمور المالية المهمة والمدفوعات المعلقة"
        }
      }
    },

    // Modules Section
    modules: {
      title: "المميزات الرئيسية للبرنامج",
      description: "استكشف الوحدات الشاملة التي تجعل داتا لايف أكاونت حلك التجاري الكامل.",
      items: {
        customization: {
          title: "التخصيص الكامل",
          features: [
            "إعداد شخصي لكل عميل",
            "تكامل شعار الشركة وصور المستخدمين",
            "التحكم عن بُعد والتحديثات"
          ]
        },
        hr: {
          title: "إدارة الموارد البشرية",
          features: [
            "قاعدة بيانات موظفين كاملة",
            "تتبع الحضور والإجازات",
            "حسابات الراتب الآلية",
            "تكامل أجهزة بصمة الإصبع",
            "إدارة التأمين الصحي"
          ]
        },
        financial: {
          title: "العمليات المالية",
          features: [
            "مراقبة الإنتاج والمخزون",
            "إدارة وتحليل التكاليف",
            "معالجة المصرفية والمدفوعات",
            "تسوية الالتزامات عبر الإنترنت",
            "تذكيرات الدفع الآلية"
          ]
        },
        analytics: {
          title: "التحليلات والتحكم",
          features: [
            "نظام التحكم في الصلاحيات",
            "تقارير مرئية بالرسوم البيانية",
            "بيانات مالية آلية",
            "إنشاء تقارير مخصصة",
            "أتمتة تحليل ضريبة القيمة المضافة"
          ]
        }
      }
    },

    // Testimonials
    testimonials: {
      title: "موثوق به من قبل قادة الأعمال",
      description: "اكتشف كيف غيّر داتا لايف أكاونت الأعمال عبر مختلف الصناعات.",
      items: [
        {
          name: "أحمد حسن",
          role: "الرئيس التنفيذي، شركة التصنيع",
          content: "داتا لايف أكاونت حوّل عمليات أعمالنا. النهج المتكامل وفر علينا ساعات لا تحصى وحسّن دقتنا المالية."
        },
        {
          name: "فاطمة الزهراء",
          role: "مديرة الموارد البشرية",
          content: "وحدة الموارد البشرية استثنائية. إدارة الموظفين وتتبع الحضور وحسابات الراتب أصبحت آلية بالكامل."
        },
        {
          name: "عمر رشيد",
          role: "مدير مالي",
          content: "أخيراً، نظام يتعامل مع كل شيء من المخزون إلى التقارير المالية. التقارير المرئية تجعل اتخاذ القرارات أسهل بكثير."
        }
      ]
    },

    // CTA Section
    cta: {
      title: "مستعد لتحويل عملك؟",
      description: "انضم إلى آلاف الشركات التي بسّطت عملياتها مع داتا لايف أكاونت. ابدأ نسختك التجريبية المجانية اليوم.",
      startTrial: "ابدأ النسخة التجريبية",
      contactSales: "اتصل بالمبيعات"
    },

    // Footer
    footer: {
      description: "شريكك في نجاح الأعمال من خلال حلول الإدارة الشاملة.",
      product: "المنتج",
      support: "الدعم",
      company: "الشركة", 
      features: "المميزات",
      pricing: "التسعير",
      demo: "العرض التوضيحي",
      documentation: "التوثيق",
      helpCenter: "مركز المساعدة",
      contact: "اتصال",
      about: "حول",
      careers: "الوظائف",
      privacy: "الخصوصية",
      copyright: "© 2025 داتا لايف أكاونت. جميع الحقوق محفوظة."
    },

    // Contact Information
    contact: {
      title: "معلومات الاتصال",
      address: "59 شارع لبنان، المهندسين، الجيزة، مصر",
      phone: "(+2) 01012625529",
      email: "info@datalifeai.com",
      businessHours: "الأحد - الخميس: 9:00 صباحاً - 6:00 مساءً",
      getInTouch: "تواصل معنا",
      contactSales: "اتصل بفريق المبيعات",
      scheduleDemo: "جدولة عرض توضيحي",
      visitOffice: "زيارة مكتبنا",
      callUs: "اتصل بنا",
      emailUs: "راسلنا"
    },

    // Pricing Section
    pricing: {
      badge: "خطط تسعير مرنة",
      title: "اختر الخطة المثالية لعملك",
      description: "من الشركات الناشئة إلى المؤسسات الكبيرة، لدينا خيارات تسعير تتناسب مع احتياجات عملك وميزانيتك.",
      popular: "الأكثر شعبية",
      recommended: "موصى به",
      employees: "موظف",
      
      tabs: {
        subscription: "خطط الاشتراك",
        modules: "حزم الوحدات",
        onetime: "إعداد لمرة واحدة"
      },

      billing: {
        monthly: "شهري",
        annual: "سنوي",
        month: "شهر",
        year: "سنة",
        save: "وفر 33%",
        savePercent: "وفر %d%"
      },

      plans: {
        starter: {
          name: "المبتدئ",
          description: "مثالي للشركات الصغيرة التي تبدأ بالإدارة الرقمية",
          features: {
            employees: "حتى 10 موظفين",
            basicHR: "إدارة الموارد البشرية الأساسية",
            financial: "التتبع المالي والتقارير",
            reports: "التقارير المالية الشهرية",
            emailSupport: "دعم عبر البريد الإلكتروني",
            storage: "5 جيجابايت تخزين سحابي"
          },
          notIncluded: {
            payroll: "معالجة الرواتب الآلية",
            advanced: "التحليلات المتقدمة والتنبؤ",
            api: "تكاملات API"
          },
          button: "ابدأ النسخة التجريبية"
        },
        professional: {
          name: "المحترف",
          description: "مثالي للشركات النامية ذات احتياجات الإدارة الشاملة",
          features: {
            employees: "حتى 100 موظف",
            fullHR: "إدارة كاملة للموارد البشرية والرواتب",
            advanced: "الإدارة المالية المتقدمة",
            inventory: "تتبع الإنتاج والمخزون",
            cost: "إدارة وتحليل التكاليف",
            priority: "دعم أولوية عبر البريد والدردشة",
            storage: "50 جيجابايت تخزين سحابي",
            reports: "تقارير وتحليلات مخصصة",
            integrations: "تكاملات API أساسية"
          },
          notIncluded: {
            multiLocation: "إدارة المواقع المتعددة",
            dedicated: "مدير حساب مخصص"
          },
          button: "احصل على المحترف"
        },
        enterprise: {
          name: "المؤسسي",
          description: "حل شامل للمؤسسات الكبيرة ذات المتطلبات المعقدة",
          unlimited: "غير محدود",
          features: {
            unlimited: "موظفين غير محدودين",
            everything: "جميع ميزات المحترف مشمولة",
            multiLocation: "إدارة المواقع والفروع المتعددة",
            customization: "سير عمل مخصص وتكاملات",
            dedicated: "مدير حساب مخصص",
            phone: "دعم هاتفي وموقعي على مدار الساعة",
            storage: "تخزين سحابي غير محدود",
            training: "تدريب شامل للموظفين",
            sla: "ضمان توفر 99.9%"
          },
          button: "اتصل بالمبيعات"
        }
      },

      modules: {
        title: "حزم الوحدات الفردية",
        description: "تحتاج وظائف محددة؟ اختر الوحدات الفردية التي تناسب متطلبات عملك بالضبط.",
        button: "احصل على هذه الوحدة",
        
        hr: {
          name: "إدارة الموارد البشرية",
          description: "حل إدارة الموارد البشرية الكامل",
          features: {
            employee: "قاعدة بيانات وملفات الموظفين",
            attendance: "تتبع الحضور والإجازات",
            payroll: "معالجة الرواتب الآلية",
            leave: "نظام إدارة الإجازات",
            insurance: "تتبع التأمين الصحي"
          }
        },
        finance: {
          name: "الإدارة المالية",
          description: "محاسبة شاملة وتتبع مالي",
          features: {
            accounting: "نظام محاسبة كامل",
            invoicing: "الفواتير والمحاسبة",
            expenses: "تتبع وإدارة المصروفات",
            banking: "مطابقة البنك",
            reports: "التقارير والتحليلات المالية"
          }
        },
        inventory: {
          name: "المخزون والإنتاج",
          description: "إدارة المخزون وتخطيط الإنتاج",
          features: {
            tracking: "تتبع المخزون في الوقت الفعلي",
            orders: "إدارة أوامر الإنتاج",
            suppliers: "إدارة الموردين والبائعين",
            analytics: "تحليلات وتنبؤات المخزون",
            alerts: "تنبيهات انخفاض المخزون والإشعارات"
          }
        }
      },

      oneTime: {
        title: "حزم الإعداد لمرة واحدة",
        description: "ابدأ بسرعة مع حزم الإعداد والتدريب الشاملة لدينا.",
        onetime: "دفعة واحدة",
        button: "شراء الإعداد",
        
        basic: {
          name: "الإعداد الأساسي",
          description: "الإعداد الأساسي لتشغيل نظامك",
          features: {
            installation: "تثبيت وتكوين النظام",
            training: "ساعتان من تدريب الموظفين",
            data: "نقل البيانات الأساسي (حتى 1000 سجل)",
            support: "30 يوم دعم عبر البريد الإلكتروني"
          }
        },
        premium: {
          name: "الإعداد المميز",
          description: "إعداد كامل مع تدريب ودعم شاملين",
          features: {
            everything: "كل شيء في الإعداد الأساسي",
            custom: "تكوين سير العمل المخصص",
            integration: "تكامل أنظمة الطرف الثالث",
            training: "8 ساعات من التدريب الشامل",
            support: "90 يوم دعم أولوية"
          }
        }
      },

      contact: {
        title: "تحتاج حل مخصص؟",
        description: "اتصل بفريق المبيعات لدينا للحصول على تسعير المؤسسات أو التكاملات المخصصة أو المتطلبات الخاصة.",
        demo: "جدولة عرض توضيحي",
        sales: "اتصل بالمبيعات"
      }
    },

    // Payment Section
    payment: {
      checkout: "الدفع الآمن",
      paymentComplete: "تم الدفع بنجاح",
      secureCheckout: "معلومات الدفع الخاصة بك آمنة ومشفرة",
      selectMethod: "اختر طريقة الدفع",
      paymentDetails: "تفاصيل الدفع",
      billingInfo: "معلومات الفوترة",
      
      methods: {
        card: "بطاقة ائتمانية/مدينة",
        cardDesc: "ادفع بأمان ببطاقتك الائتمانية أو المدينة",
        fawryDesc: "ادفع من خلال منافذ فوري أو تطبيق الموبايل",
        bank: "تحويل بنكي",
        bankDesc: "تحويل بنكي مباشر (1-2 يوم عمل)",
        wallet: "محفظة موبايل",
        walletDesc: "فودافون كاش، أورانج موني، اتصالات كاش"
      },

      instant: "فوري",
      bankTime: "1-2 يوم عمل",

      cardNumber: "رقم البطاقة",
      expiryDate: "تاريخ الانتهاء",
      cvv: "رمز الأمان",
      cardName: "اسم حامل البطاقة",
      cardNamePlaceholder: "الاسم كما يظهر على البطاقة",
      email: "البريد الإلكتروني",
      phone: "رقم الهاتف",
      companyName: "اسم الشركة",
      companyNamePlaceholder: "اسم الشركة الخاصة بك",
      vatNumber: "الرقم الضريبي",
      optional: "اختياري",
      walletPhone: "رقم هاتف المحفظة",

      fawryInstructions: "تعليمات الدفع عبر فوري",
      fawrySteps: "1. أكمل هذا النموذج 2. اذهب إلى أي منفذ فوري 3. استخدم رمز الدفع المقدم 4. سيتم تفعيل حسابك فوراً",

      bankInstructions: "تعليمات التحويل البنكي", 
      bankDetails: "الحساب: شركة داتا لايف أكاونت | البنك: البنك التجاري الدولي | رقم الحساب: 123456789 | المرجع: رقم طلبك",

      back: "رجوع",
      continue: "متابعة",
      cancel: "إلغاء",
      payNow: "ادفع الآن",

      processing: "جاري معالجة الدفع",
      processingDesc: "يرجى الانتظار أثناء معالجة الدفع. لا تغلق هذه النافذة.",

      success: "تم الدفع بنجاح!",
      successDesc: "تم تفعيل اشتراكك وستتلقى تفاصيل التأكيد قريباً.",

      transactionId: "رقم المعاملة",
      amount: "المبلغ",
      plan: "الخطة",
      save: "توفر",

      emailSent: "تم إرسال بريد التأكيد",
      smsSent: "تم إرسال إشعار SMS",
      accountActivated: "تم تفعيل الحساب",
      getStarted: "ابدأ الآن",

      securePayment: "دفع آمن مشفر 256-بت SSL"
    },

    // Demo Section
    demo: {
      title: "داتا لايف أكاونت - العرض التوضيحي المباشر",
      subtitle: "اختبر القوة الكاملة لمنصة إدارة الأعمال الخاصة بنا",
      demoMode: "وضع العرض التوضيحي",
      guidedTour: "ابدأ الجولة المرشدة",
      
      modules: {
        dashboard: "لوحة التحكم",
        hr: "إدارة الموارد البشرية", 
        financial: "المالية",
        inventory: "المخزون",
        reports: "التقارير",
        analytics: "التحليلات"
      },

      kpi: {
        totalEmployees: "إجمالي الموظفين",
        monthlyRevenue: "الإيرادات الشهرية",
        activeProjects: "المشاريع النشطة", 
        efficiency: "معدل الكفاءة"
      },

      currency: "جنيه مصري",

      quickActions: {
        title: "الإجراءات السريعة",
        addEmployee: "إضافة موظف",
        newTransaction: "معاملة جديدة", 
        generateReport: "إنشاء تقرير",
        checkInventory: "فحص المخزون"
      },

      recentActivity: {
        title: "النشاط الحديث"
      },

      upcomingTasks: {
        title: "المهام القادمة"
      },

      hr: {
        totalEmployees: "إجمالي الموظفين",
        presentToday: "الحاضرون اليوم",
        onLeave: "في إجازة",
        employeeList: "قائمة الموظفين",
        addEmployee: "إضافة موظف",
        employee: "الموظف",
        position: "المنصب",
        department: "القسم", 
        status: "الحالة",
        actions: "الإجراءات"
      },

      financial: {
        recentTransactions: "المعاملات الحديثة",
        newTransaction: "معاملة جديدة",
        date: "التاريخ",
        description: "الوصف",
        category: "الفئة",
        amount: "المبلغ",
        status: "الحالة"
      },

      inventory: {
        items: "عناصر المخزون",
        filter: "تصفية",
        addItem: "إضافة عنصر",
        product: "المنتج",
        sku: "رمز المنتج",
        quantity: "الكمية",
        value: "القيمة",
        status: "الحالة"
      },

      reports: {
        financialSummary: "الملخص المالي",
        monthlyRevenue: "الإيرادات الشهرية",
        expenses: "المصروفات حسب الفئة"
      },

      tour: {
        welcome: "مرحباً بك في عرض داتا لايف التوضيحي!",
        description: "دعنا نرشدك عبر الميزات الرئيسية لداتا لايف أكاونت.",
        start: "ابدأ الجولة"
      },

      // Demo Content
      recentActivityItems: [
        "تم إضافة الموظف أحمد حسن إلى نظام الموارد البشرية",
        "تمت معالجة كشوف المرتبات الشهرية بنجاح",
        "تنبيه المخزون: مستلزمات المكتب منخفضة",
        "تم إنشاء التقرير المالي",
        "تم إضافة عقد مورد جديد"
      ],

      upcomingTasksItems: [
        "معالجة كشوف المرتبات الشهرية",
        "مراجعة فواتير الموردين",
        "تحديث مستويات المخزون",
        "إنشاء التقرير الفصلي"
      ],

      dueDates: [
        "مستحق غداً",
        "مستحق خلال يومين",
        "مستحق خلال 3 أيام",
        "مستحق الأسبوع القادم"
      ],

      timeAgo: [
        "منذ دقيقتين",
        "منذ ساعة واحدة",
        "منذ 3 ساعات",
        "منذ 5 ساعات",
        "منذ يوم واحد"
      ],

      // Employee Form
      employeeForm: {
        tabs: {
          basic: "المعلومات الأساسية",
          job: "التفاصيل الوظيفية",
          financial: "المعلومات المالية",
          documents: "الوثائق والمرفقات",
          transfers: "سجل الانتقالات"
        },
        
        basic: {
          personalInfo: "المعلومات الشخصية",
          fullName: "الاسم الكامل",
          email: "البريد الإلكتروني",
          phone: "رقم الهاتف",
          nationalId: "الرقم القومي",
          birthDate: "تاريخ الميلاد",
          gender: "النوع",
          male: "ذكر",
          female: "أنثى",
          maritalStatus: "الحالة الاجتماعية",
          single: "أعزب",
          married: "متزوج",
          divorced: "مطلق",
          address: "العنوان"
        },
        
        job: {
          jobDetails: "التفاصيل الوظيفية",
          position: "المنصب",
          department: "القسم",
          directManager: "المدير المباشر",
          startDate: "تاريخ بداية العمل",
          employmentType: "نوع التوظيف",
          fullTime: "دوام كامل",
          partTime: "دوام جزئي",
          contract: "عقد",
          internship: "تدريب",
          workLocation: "مكان العمل"
        },
        
        financial: {
          salaryInfo: "المعلومات المالية",
          baseSalary: "الراتب الأساسي",
          allowances: "البدلات",
          allowanceType: "نوع البدلة",
          allowanceAmount: "مبلغ البدلة",
          transportation: "بدل مواصلات",
          housing: "بدل سكن",
          food: "بدل طعام",
          communication: "بدل اتصالات",
          other: "أخرى",
          deductions: "الخصومات",
          deductionType: "نوع الخصم",
          deductionAmount: "مبلغ الخصم",
          insurance: "تأمين",
          tax: "ضرائب",
          loan: "قرض",
          payrollMethod: "طريقة الدفع",
          cash: "نقداً",
          bank: "تحويل بنكي",
          bankAccount: "رقم الحساب البنكي"
        },
        
        documents: {
          documentsFiles: "الوثائق والملفات",
          profileImage: "الصورة الشخصية",
          uploadImage: "رفع صورة",
          cv: "السيرة الذاتية",
          uploadCV: "رفع السيرة الذاتية",
          contracts: "عقود العمل",
          uploadContract: "رفع عقد",
          certificates: "الشهادات والمؤهلات",
          uploadCertificate: "رفع شهادة",
          supportedFormats: "الصيغ المدعومة: PDF, DOC, JPG, PNG",
          maxSize: "الحد الأقصى: 5 ميجا بايت"
        },
        
        transfers: {
          transferHistory: "سجل الانتقالات",
          addTransfer: "إضافة انتقال",
          fromDepartment: "من القسم",
          toDepartment: "إلى القسم",
          transferDate: "تاريخ الانتقال",
          reason: "السبب",
          promotion: "ترقية",
          departmentChange: "تغيير قسم",
          locationChange: "تغيير موقع",
          restructuring: "إعادة هيكلة",
          notes: "ملاحظات"
        },
        
        actions: {
          save: "حفظ الموظف",
          cancel: "إلغاء",
          next: "التالي",
          previous: "السابق",
          addAllowance: "إضافة بدلة",
          addDeduction: "إضافة خصم",
          removeAllowance: "حذف البدلة",
          removeDeduction: "حذف الخصم",
          addDepartment: "إضافة قسم جديد",
          addCustomType: "إضافة نوع مخصص"
        },

        customTypes: {
          allowanceTitle: "إضافة نوع بدلة مخصص",
          deductionTitle: "إضافة نوع خصم مخصص", 
          nameAr: "الاسم بالعربية",
          nameEn: "الاسم بالإنجليزية",
          save: "حفظ النوع",
          cancel: "إلغاء",
          namePlaceholder: "أدخل اسم النوع",
          custom: "مخصص"
        },

        newTransaction: {
          title: "إضافة معاملة جديدة",
          description: "الوصف",
          category: "الفئة",
          amount: "المبلغ",
          type: "النوع",
          date: "التاريخ",
          income: "دخل",
          expense: "مصروف",
          save: "حفظ المعاملة",
          cancel: "إلغاء",
          categories: {
            salary: "راتب",
            rent: "إيجار",
            utilities: "مرافق",
            supplies: "مستلزمات",
            marketing: "تسويق",
            maintenance: "صيانة",
            sales: "مبيعات",
            other: "أخرى"
          }
        },

        addDepartment: {
          title: "إضافة قسم جديد",
          name: "اسم القسم",
          nameAr: "الاسم بالعربية",
          nameEn: "الاسم بالإنجليزية",
          description: "وصف القسم",
          manager: "مدير القسم",
          save: "حفظ القسم",
          cancel: "إلغاء",
          namePlaceholder: "أدخل اسم القسم",
          descriptionPlaceholder: "وصف مختصر للقسم وأهدافه"
        }
      }
    },

    // Free Trial Section
    trial: {
      title: "ابدأ نسختك التجريبية المجانية لمدة 14 يوماً",
      description: "اختبر القوة الكاملة لداتا لايف أكاونت بدون أي التزام. احصل على وصول فوري لجميع ميزات الخطة المحترفة.",
      
      benefits: {
        title: "ما المتضمن في نسختك التجريبية المجانية"
      },
      
      features: {
        duration: "14 يوماً وصول كامل",
        durationDesc: "فترة تجريبية كاملة بدون قيود",
        employees: "حتى 25 موظف",
        employeesDesc: "مثالي للاختبار مع فريقك",
        fullAccess: "جميع الميزات المحترفة",
        fullAccessDesc: "الموارد البشرية، المالية، المخزون، التقارير والمزيد",
        support: "دعم عبر البريد الإلكتروني",
        supportDesc: "احصل على المساعدة عند الحاجة"
      },

      form: {
        title: "أنشئ حساب نسختك التجريبية المجانية",
        firstName: "الاسم الأول",
        firstNamePlaceholder: "أدخل اسمك الأول",
        lastName: "اسم العائلة", 
        lastNamePlaceholder: "أدخل اسم العائلة",
        email: "البريد الإلكتروني",
        phone: "رقم الهاتف",
        companyName: "اسم الشركة",
        companyNamePlaceholder: "أدخل اسم شركتك",
        businessInfo: "معلومات العمل (اختيارية)",
        industry: "الصناعة",
        selectIndustry: "اختر صناعتك",
        companySize: "حجم الشركة",
        selectSize: "اختر حجم الشركة",
        intendedUse: "حالة الاستخدام الأساسية",
        selectUse: "كيف ستستخدم داتا لايف؟",
        cancel: "إلغاء",
        startTrial: "ابدأ نسختي التجريبية المجانية"
      },

      processing: {
        title: "إعداد حساب نسختك التجريبية",
        description: "يرجى الانتظار بينما نحضر تجربة داتا لايف أكاونت الشخصية لك..."
      },

      success: {
        header: "مرحباً بك في داتا لايف أكاونت!",
        title: "نسختك التجريبية المجانية جاهزة!",
        description: "لقد أنشأنا حسابك وأضفنا بيانات عينة حتى تتمكن من البدء في الاستكشاف فوراً.",
        trialLength: "مدة التجربة",
        days: "أيام",
        maxEmployees: "حد الموظفين",
        employees: "موظف",
        features: "الوصول للميزات",
        fullAccess: "جميع الميزات المحترفة",
        emailSent: "تم إرسال بريد ترحيبي مع تفاصيل تسجيل الدخول",
        accountCreated: "تم إنشاء وتفعيل الحساب التجريبي",
        sampleData: "تم إضافة بيانات عينة للاختبار الفوري",
        accessTrial: "الوصول لحسابي التجريبي"
      },

      security: "لا حاجة لبطاقة ائتمانية. ألغِ في أي وقت."
    }
  }
};

export const getTranslation = (language, key) => {
  const keys = key.split('.');
  let translation = translations[language];
  
  for (const k of keys) {
    translation = translation?.[k];
  }
  
  return translation || key;
};